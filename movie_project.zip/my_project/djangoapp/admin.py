from django.contrib import admin
from djangoapp.models import user
# Register your models here.
admin.site.register(user)